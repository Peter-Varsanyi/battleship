package com.epam.torpedo;

public enum HitType {
	MISS, SINGLE, SUNK
}
